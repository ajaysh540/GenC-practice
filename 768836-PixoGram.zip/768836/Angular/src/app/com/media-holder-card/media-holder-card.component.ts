import { Component, OnInit, Input } from '@angular/core';
import { Media } from 'src/model/media';
import { DataService } from 'src/services/data.service';
import { User } from 'src/model/user';
import { UserAuthService } from 'src/services/user-auth.service';

@Component({
  selector: 'app-media-holder-card',
  templateUrl: './media-holder-card.component.html',
  styleUrls: ['./media-holder-card.component.css']
})
export class MediaHolderCardComponent implements OnInit {

  @Input()
  mediaDetails: Media;
  user:User;
  name:String;
  constructor(private dataService: DataService, private mediaService: UserAuthService) {
  }

  ngOnInit() {
      this.mediaService.getUserById(this.mediaDetails.userId).subscribe((result)=>{
        this.user=result;
        ////console.log(result);
        ////console.log(this.user);
        this.name=this.user.name;
      })
  }
 

  sendMediaDetails(id) {
   // //console.log(id);
    this.dataService.sendMediaDetails(this.mediaDetails);
  }

}
