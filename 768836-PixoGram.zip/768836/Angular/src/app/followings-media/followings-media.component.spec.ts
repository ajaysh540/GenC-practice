import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowingsMediaComponent } from './followings-media.component';

describe('FollowingsMediaComponent', () => {
  let component: FollowingsMediaComponent;
  let fixture: ComponentFixture<FollowingsMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowingsMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowingsMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
