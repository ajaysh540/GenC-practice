import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { MediaService } from 'src/services/media.service';
import { Media } from 'src/model/media';

@Component({
  selector: 'app-followings-media',
  templateUrl: './followings-media.component.html',
  styleUrls: ['./followings-media.component.css']
})
export class FollowingsMediaComponent implements OnInit {

  userId;
  medias:Media[];
  constructor(private titleService: Title, private router: Router, private mediaService: MediaService) { 
    let userId = localStorage.getItem("userId");
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
    titleService.setTitle("PixoHome");
    this.userId=parseInt(localStorage.getItem("userId"));
    mediaService.getFollowingsMedia(this.userId).subscribe(response=>{
      this.medias=response;
      //////console.log(this.medias);
      for (let i = 0; i < this.medias.length; i++) {
        let oldUrl = this.medias[i].url;
       // if (this.medias[i].likeCount == -1)
          this.medias[i].url = `http://localhost:8080/${oldUrl}`;
       // else
        //  this.medias[i].url = `http://localhost:8080/files/${oldUrl}`;
      }
    })
  }

  ngOnInit() {
  }

}
