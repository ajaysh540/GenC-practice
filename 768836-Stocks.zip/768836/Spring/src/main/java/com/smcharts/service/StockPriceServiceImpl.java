package com.smcharts.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smcharts.model.StockPrice;
import com.smcharts.repo.StockPriceRepo;

@Service
public class StockPriceServiceImpl implements StockPriceService {

	@Autowired
	StockPriceRepo stockPriceRepo;

	public List<StockPrice> getStockPrices() {
		return (List<StockPrice>) stockPriceRepo.findAll();
	}

	@Override
	public StockPrice createStockPrice(StockPrice stockPrice) {
		return stockPriceRepo.save(stockPrice);
	}

	@Override
	public Optional<StockPrice> getStockPriceById(Long id) {
		return stockPriceRepo.findById(id);
	}

	@Override
	public List<StockPrice> getStockPricesbyCompanyId(long id) {
		List<StockPrice> stocks = new ArrayList<>();

		stocks = stockPriceRepo.getByCompanyId(id);
		Collections.sort(stocks,new StocksComparator(StockPrice.stocksTime));

		System.out.println(stocks);
		return stocks;
	}

	@Override
	public void exportExcel(MultipartFile file) throws Exception {
		try {

			//List<StockPrice> stockList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
			XSSFSheet worksheet = workbook.getSheetAt(0);
			SimpleDateFormat date=new SimpleDateFormat("yyyy/MM/dd");
			//SimpleDateFormat time=new SimpleDateFormat("hh:mm:ss");
			for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
				StockPrice stock = new StockPrice();

				XSSFRow row = worksheet.getRow(i);
			
				
				System.out.print((long) row.getCell(1).getNumericCellValue()+" ");
				System.out.print((long) row.getCell(2).getNumericCellValue()+" ");
				System.out.print(row.getCell(3).getStringCellValue()+" ");	
			System.out.print(row.getCell(4).getStringCellValue()+" ");
			
//				String t=time.format(row.getCell(4).getDateCellValue());
				String d=date.format(row.getCell(5).getDateCellValue());
				System.out.println(d);
				stock.setCompanyId((long) row.getCell(1).getNumericCellValue());
				stock.setCurrentPrice((long) row.getCell(2).getNumericCellValue());
				stock.setStockExchangeName(row.getCell(3).getStringCellValue());
				stock.setDate(d);
				stock.setTime(row.getCell(4).getStringCellValue());

				//stockList.add(stock);
				System.out.println(stock.toString());
				stockPriceRepo.save(stock);
				
			}
			//System.out.println(stockList.get(0));
			workbook.close();
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	@Override
	public List<StockPrice> getStockPricesCompare1(long companyId, long stockExchangeId, String periodicity) {

		List<StockPrice> stocks = new ArrayList<>();

		stocks = stockPriceRepo.getByCompanyId(companyId);
		Collections.sort(stocks,new StocksComparator(StockPrice.stocksDate,StockPrice.stocksTime));

		System.out.println(stocks);

//		for (String[] s : times) {
//	
		return stocks;
	}

	@Override
	public List<StockPrice> getBySector(String sector) {
		// TODO Auto-generated method stub
		return stockPriceRepo.getBySector(sector);
	}



}
