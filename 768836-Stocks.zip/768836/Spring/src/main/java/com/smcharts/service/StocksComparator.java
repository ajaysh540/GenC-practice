package com.smcharts.service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.smcharts.model.StockPrice;

public class StocksComparator implements Comparator<StockPrice> {
	private List <Comparator<StockPrice>> l;
	@SafeVarargs
	public StocksComparator(Comparator<StockPrice>...comparators) {
		this.l=Arrays.asList(comparators);
	}
	
	
	@Override
	public int compare(StockPrice arg0, StockPrice arg1) {
		for(Comparator<StockPrice> comparator:l) {
			int res=comparator.compare(arg0, arg1);
			if(res!=0) return res;
		}
		return 0;
	}

	

}
