import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input()
  role: String;
  @Input()
  username: String;
  
  userId: number;
  user: User;

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
    //console.log(this.role);
    let userId = localStorage.getItem("userId");
    this.userId = parseInt(userId);
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
    this.username=localStorage.getItem("userName");
    this.userId=parseInt(localStorage.getItem("userId"));

  }

  logout(){
    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("mobile");
    this.router.navigate(['sign-in']);
  }

}
