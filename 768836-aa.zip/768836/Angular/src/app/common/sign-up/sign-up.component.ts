import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  username: String;
  password: String;
  email: String;
  mobile: String;
  user: User;
  rForm: FormGroup;
  rPassword: String;
  validUser: Boolean;

  constructor(private router: Router,private userService: UserService,private fb:FormBuilder,private title:Title) { 
    title.setTitle("SignUp-StockMarket");
    this.onFormSubmit();
   }

  ngOnInit() {
  
  }

  onSubmit() {
    this.userService.registerUser(new User(this.username, this.password, this.email, "USER", this.mobile)).subscribe(
      async res => { 
        this.user = await res;
        this.router.navigate(['sign-in'])
        alert("User Registered successfully!!!")
       },
      error => console.log(error)
    );
  }

  onFormSubmit(){
    this.rForm=this.fb.group({
      'username': [this.username, Validators.compose([Validators.required])],
      'password': [this.password, Validators.compose([Validators.required, Validators.minLength(5)])],
      'rpassword': [this.rPassword, Validators.compose([Validators.required])],
      'email': [this.email, Validators.compose([Validators.email, Validators.required])],
      'mobile': [this.mobile, Validators.compose([Validators.minLength(10)])]
    },
    {validator: this.passwordMatchValidator}
    )
  }

  passwordMatchValidator(frm: FormGroup) {
    return frm.controls['password'].value === frm.controls['rpassword'].value ? null : {'mismatch': true};
  }

  checkUserName(){
    this.userService.checkUser(this.username).subscribe(response => {
      this.validUser=response
    },err=>{
      console.log("err")
    });
  }
}
