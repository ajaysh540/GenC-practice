import { Component, OnInit } from '@angular/core';
import { IPO } from 'src/app/models/ipo';
import { Router } from '@angular/router';
import { IpoService } from 'src/app/service/ipo.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'manage-ipo',
  templateUrl: './manage-ipo.component.html',
  styleUrls: ['./manage-ipo.component.css'],
})
export class ManageIpoComponent implements OnInit {

  userId: number;
  ipos: IPO[];

  constructor(private router: Router, private ipoService: IpoService,private title:Title) {
    title.setTitle("IPO List");
   }

  ngOnInit() {
    let userId = localStorage.getItem("userId");
    this.userId = parseInt(userId);
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
    this.ipoService.getIpos().subscribe(async res => {
      this.ipos = await res;
      //console.log(this.ipos);
    })
  }
}
