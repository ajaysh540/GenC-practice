import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';
import { User } from 'src/app/models/user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  userId: number;
  username: String;
  password: String;
  email: String;
  mobile: String;
  user: User;
  rForm1: FormGroup;
  rPassword: String;
  constructor(private router: Router, private userService: UserService,private fb: FormBuilder,private title:Title) { 
    title.setTitle("User Update Details");
    this.onFormSubmit();
    
   }

  ngOnInit() {
    let userId = localStorage.getItem("userId");
    this.userId = parseInt(userId);
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
    this.email=localStorage.getItem('userEmail');
    this.username=localStorage.getItem('userName');
    this.mobile=localStorage.getItem('mobile');
    this.userId=parseInt(localStorage.getItem('userId'));
    //console.log(this.email,this.username,this.mobile,this.userId);
  }

  onSubmit() {
    this.userService.registerUser(new User(this.username, this.password, this.email, "USER", this.mobile, this.userId)).subscribe(
      async res => { 
        this.user = await res;
        this.router.navigate(['user/details'])
       },
      error => console.log(error)
    );
  }

  onFormSubmit(){
    this.rForm1=this.fb.group({
      'username':[this.username],
      'password': [this.password, Validators.compose([Validators.required, Validators.minLength(5)])],
      'rpassword': [this.rPassword, Validators.compose([Validators.required])],
      'email': [this.email, Validators.compose([Validators.email, Validators.required])],
      'mobile': [this.mobile, Validators.compose([Validators.minLength(10)])]
    },
    {validator: this.passwordMatchValidator}
    )
  }

  passwordMatchValidator(frm: FormGroup) {
    return frm.controls['password'].value === frm.controls['rpassword'].value ? null : {'mismatch': true};
  }

}
