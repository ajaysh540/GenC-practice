import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {

  role: String = "USER";
  username: String = "user1";

  constructor(private title:Title) { 
    title.setTitle("Search Company");}

  ngOnInit() {}
  

}
