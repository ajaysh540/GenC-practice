package com.smcharts.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.datetime.DateFormatter;

@Entity
@Table(name = "stock_price")
public class StockPrice {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "company_id")
	private long companyId;

	@Column(name = "stock_exchange_name")
	private String stockExchangeName;

	@Column(name = "current_price")
	private long currentPrice;

	@Column
	private String date;

	@Column
	private String time;

	public StockPrice() {

	}

	public StockPrice(long companyId, String stockExchangeName, long currentPrice, String date, String time) {
		this.companyId = companyId;
		this.stockExchangeName = stockExchangeName;
		this.currentPrice = currentPrice;
		this.date = date;
		this.time = time;
	}

	public long getCompanyId() {
		return companyId;
	}

	public long getCurrentPrice() {
		return currentPrice;
	}

	public String getDate() {
		return date;
	}

	public String getStockExchangeName() {
		return stockExchangeName;
	}

	public String getTime() {
		return time;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public void setCurrentPrice(long currentPrice) {
		this.currentPrice = currentPrice;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setStockExchangeName(String stockExchangeName) {
		this.stockExchangeName = stockExchangeName;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "StockPrice [companyId=" + companyId + ", stockExchangeName=" + stockExchangeName + ", currentPrice="
				+ currentPrice + ", date=" + date + ", time=" + time + "]";
	}

	public static Comparator<StockPrice> stocksDate= new Comparator<StockPrice>(){
		public int compare(StockPrice s1,StockPrice s2) {
			SimpleDateFormat dateFormmater= new SimpleDateFormat("yyyy/MM/dd");
			Date d1 = null;
			Date d2 = null;
			try {
			d1=dateFormmater.parse(s1.getDate());
			d2=dateFormmater.parse(s2.getDate());
			
			}
			catch(ParseException e) {
				System.out.println(e.getMessage());
							}
			return d1.compareTo(d2);
		}
		
	};
	
	public static Comparator<StockPrice> stocksTime= new Comparator<StockPrice>(){
		public int compare(StockPrice s1,StockPrice s2) {
			SimpleDateFormat dateFormmater= new SimpleDateFormat("hh:mm:ss");
			Date d1 = null;
			Date d2 = null;
			try {
			d1=dateFormmater.parse(s1.getTime());
			d2=dateFormmater.parse(s2.getTime());
			
			}
			catch(ParseException e) {
				System.out.println(e.getMessage());
							}
			return d1.compareTo(d2);
			//return   (int) (d1.getTime()-d2.getTime());
		}
		
	};
	
	
}
