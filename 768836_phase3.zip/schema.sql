
  
CREATE TABLE if not exists USER_DETAILS (

  id INT AUTO_INCREMENT  PRIMARY KEY,
  
	 FirstName varchar(30) Not Null,
	 LastName varchar(30) Not Null,
	 Username varchar(30) Not Null,
	 Email varchar(30) Not Null,
	 Password varchar(30) Not Null,
	 ProfilePicture varchar(30) Not Null,
);


create table if not exists image_video(
	ID INT auto_increment Primary Key,
	title varchar(20) not Null,
	description varchar(100) not null,
	tags varchar(100) not null,
	image boolean not null default 'true',
	url varchar(200) 
);




