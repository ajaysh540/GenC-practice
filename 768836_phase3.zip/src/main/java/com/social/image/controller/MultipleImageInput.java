package com.social.image.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.social.image.input.ImageInput;
import com.social.image.pojo.ImageVideo;

public class MultipleImageInput {
	
	public List<ImageVideo> multipleImages(int n){
		List<ImageVideo> li=new ArrayList<>();
		
		for(int i=0;i<n;i++) {
			
			try {
				ImageVideo iv=ImageInput.enterMediaDetails();
				li.add(iv);
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		return li;
	}

}
