package com.social.image.controller;

import java.io.IOException;

import com.social.image.input.ImageInput;
import com.social.image.pojo.ImageVideo;

public class SingleImageInput  {
	public ImageVideo singleImage() {
		ImageVideo img=null;
	try {
	img=ImageInput.enterMediaDetails();
	
	}
	catch(IOException e){
		e.printStackTrace();
	}
	return img;
	}
}
