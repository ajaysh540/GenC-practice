package com.social.image.database;

public class ImageDB {

}
