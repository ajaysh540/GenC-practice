package com.social.image.display;

import java.util.List;

import com.social.image.pojo.ImageVideo;
import com.social.image.service.ImageService;

public class ImageOutput {

	public static void displayImages(ImageService imageService) {
		List<ImageVideo> li= (List<ImageVideo>) imageService.findAll();
		
		System.out.println(li.toString());
	}
	
}
