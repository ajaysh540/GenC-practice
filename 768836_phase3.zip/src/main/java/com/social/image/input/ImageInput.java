package com.social.image.input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.social.image.pojo.ImageVideo;

public class ImageInput {
	static int Id;
	static String title;
	static String descirption;
	static String tags;
	static boolean image;
	static String url;
	static char im;
	public static ImageVideo enterMediaDetails() throws IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do {
		System.out.println("I for image/ V for video");
		im=br.readLine().charAt(0);
		}
		while(im!='i' && im!='I' && im!='v' && im!='V');
		if(im=='i' || im=='I') {
			image=true;
		}
		else image=false;
		System.out.println("Title");
		title=br.readLine();
		System.out.println("Description");
		descirption=br.readLine();
		System.out.println("Tags");
		tags=br.readLine();
		System.out.println("url");
		url=br.readLine();
		
		ImageVideo imageVideo=new ImageVideo();
		imageVideo.setTitle(title);
		imageVideo.setTags(tags);
		imageVideo.setUrl(url);
		imageVideo.setImage(image);
		imageVideo.setDescirption(descirption);
		return imageVideo;
	}
}
