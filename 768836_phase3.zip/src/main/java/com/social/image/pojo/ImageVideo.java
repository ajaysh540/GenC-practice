package com.social.image.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="image_video")
public class ImageVideo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int Id;
	String Title;
	String Descirption;
	String Tags;
	boolean Image;
	String Url;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		this.Title = title;
	}
	public String getDescirption() {
		return Descirption;
	}
	public void setDescirption(String descirption) {
		this.Descirption = descirption;
	}
	public String getTags() {
		return Tags;
	}
	public void setTags(String tags) {
		this.Tags = tags;
	}
	public boolean isImage() {
		return Image;
	}
	public void setImage(boolean image) {
		this.Image = image;
	}
	public String getUrl() {
		return Url;
	}
	public void setUrl(String url) {
		this.Url = url;
	}
	@Override
	public String toString() {
		return "ImageVideo [Id=" + Id + ", title=" + Title + ", descirption=" + Descirption + ", tags=" + Tags
				+ ", image=" + Image + ", url=" + Url + "]";
	}
	
}
