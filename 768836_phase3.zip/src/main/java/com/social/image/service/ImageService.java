package com.social.image.service;

import org.springframework.data.repository.CrudRepository;

import com.social.image.pojo.ImageVideo;

public interface ImageService extends CrudRepository<ImageVideo, Integer>{

}
