package com.social.image.upload;

import java.util.List;

import com.social.image.controller.MultipleImageInput;
import com.social.image.controller.SingleImageInput;
import com.social.image.display.ImageOutput;
import com.social.image.pojo.ImageVideo;
import com.social.image.service.ImageService;

public class MediaUpload {

	public static void singleUpload(ImageService imageService) {
		SingleImageInput singleImageInput=new SingleImageInput();
		ImageVideo iv=singleImageInput.singleImage();
		imageService.save(iv);
		ImageOutput.displayImages(imageService);
	}

	
	public static void multipleUpload(int n,ImageService imageService) {
		MultipleImageInput multipleImageInput=new MultipleImageInput();
		List<ImageVideo> li=multipleImageInput.multipleImages(n);
		imageService.saveAll(li);
		ImageOutput.displayImages(imageService);
	}
}
