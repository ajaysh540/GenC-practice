package com.social.imageApp.Pixogram;

import java.util.Scanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import com.social.image.service.ImageService;
import com.social.image.upload.MediaUpload;
import com.social.user.mainRegistration.UserRegistration;
import com.social.user.service.UserService;


@SpringBootApplication
@EntityScan("com.social.user")
@EnableJpaRepositories("com.social.user")
public class PixogramApplication {
	
	@Autowired 
	public static UserService userService;
	
	@Autowired 
	public static  ImageService imageService;
	
	
	
	@Autowired
	public static JdbcTemplate jtm;
	
	public static void main(String[] args) {	
		
		System.out.println("Select opeartion\n1. User REgister\n2. Single media Upload\n3. Multiple media upload");
		int n;
				Scanner s=new Scanner(System.in);
				n=s.nextInt();
		switch(n) {
		case 1: UserRegistration register=new UserRegistration();
				register.registerNewUser(userService);
				break;
		case 2: MediaUpload.singleUpload(imageService);
							
				break;
		case 3:		System.out.println("Enter Number of images: (max 5)");
					n=s.nextInt();
					MediaUpload.multipleUpload(n, imageService);
				break;
		}
		
		s.close();
	}
		
		
		@Autowired
		public void setRepository(UserService service) {
			PixogramApplication.userService=service;
		}
		@Autowired
		public void setRepositoryimage(ImageService service) {
			PixogramApplication.imageService=service;
		}

	

}
