package com.social.imageApp.account.controllers;

public class LogoutController {

}
