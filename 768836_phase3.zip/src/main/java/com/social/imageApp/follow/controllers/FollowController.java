package com.social.imageApp.follow.controllers;

public class FollowController {

}
