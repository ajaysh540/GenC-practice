package com.social.imageApp.mymedia.controllers;

public class MyMediaController {

}
