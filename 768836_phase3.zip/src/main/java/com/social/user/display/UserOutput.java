package com.social.user.display;

public class UserOutput {

}
