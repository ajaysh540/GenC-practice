package com.social.user.input;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



import com.social.user.pojo.User;

public class UserInput {
	
	User user=new User();
	
	String firstName;
	String lastName;
	String userName;
	String email;
	String password;
	String password1;
	String profilePic;
	public User getUser() throws IOException{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Firstname");
		firstName=br.readLine();
		
		System.out.println("Enter Lastname");
		lastName=br.readLine();
		
		System.out.println("Enter Username");
		userName=br.readLine();
		
		System.out.println("Enter Email");
		email=br.readLine();
		
		do {
		System.out.println("Enter password");
		password=br.readLine();
		
		System.out.println("Confirm password");
		password1=br.readLine();
		System.out.println(password+" "+ password1);
		}
		while(!password.equals(password1));
		
		System.out.println("Enter Profile pic url");
		profilePic=br.readLine();
		
		
		
		
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setEmail(email);
		user.setUsername(userName);
		user.setPassword(password);
		user.setProfilePicture(profilePic);
		return user;
		
	}
	
}
