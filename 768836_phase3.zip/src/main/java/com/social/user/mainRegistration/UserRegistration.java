package com.social.user.mainRegistration;


import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.social.imageApp.Pixogram.PixogramApplication;
import com.social.user.input.UserInput;
import com.social.user.pojo.User;
import com.social.user.service.UserService;



public class UserRegistration {

private static Logger logger = Logger.getLogger(PixogramApplication.class.getName());
	

	@Autowired
	public static JdbcTemplate jtm;
	
	public void registerNewUser(UserService userService) {
		UserInput userIn=new UserInput();
		try {
			User user= userIn.getUser();
			System.out.println(user.getFirstName()+" "+user.getLastName()+" "+user.getEmail()+" "+user.getPassword()+" "+user.getProfilePicture()+" "+user.getUsername());
			userService.save(user);
		
			userService.findAll().forEach(setting -> {
	            logger.info(setting.toString());
	        });
			List<User> userList = (List<User>) userService.findAll();
			System.out.println(userList.toString());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		
		


}
