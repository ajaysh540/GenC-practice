package com.social.user.service;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.social.user.pojo.User;
@Repository
public interface UserService  extends CrudRepository<User, Integer>{
//	@Query("FROM User ORDER BY FirstName order by LastName")
//    List<User> findAllOrderByName();
}
