package com.social.user.utilities;

public class UserValidation {

}
