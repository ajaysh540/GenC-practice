# Services

> create
> register
> consume

# register a service in 3 way
> @injectable -> provideIn
> app module -> provider[]
> component -> provider[]

# Angular Forms
> Forms are important when we want to take input or data from the user
> Forms is essential part in your application as with the help of forms user can
  interact with your aplication

# we can create forms in two ways
1. Template Driven Forms (TDF)
2. Reactive Forms or Model driven forms

> TDF - heavy work is done in the template
> Reactive Forms - heavy work is done in the component class


# Template Driven Forms
> Easy to use and similar to angular JS
> Two way binding can be achieve by ngModel
> Bulky html and component code minimal
> Automatically track the form and form element state and validity
> Unit testing is a challenge
> Readabilty decreases with complex form and validation
> Suitable for simple forms


# Steps
1. Add the html in the component
2. Binding Data
3. TRack state and validations
4. Display error message
5. submit the form

form can have 3 state
> the control has been visited or not
> the control value has been changed or not
> the control value is valid or not


# form state
> untouched - ng-untouched - after the form load on the browser we never touched the element
> touched - ng-touched - after form loads we touched the element
> prestine - ng-pristine - we never modify the value
> dirty - ng-dirty - we modified the value
> valid - ng-valid - value is valid
> invalid - ng-invalid - value in invalid






