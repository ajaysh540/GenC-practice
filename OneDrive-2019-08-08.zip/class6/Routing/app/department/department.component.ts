import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {


  constructor(private router: Router) { }

  ngOnInit() {
  }

  public departments = [
    {id: 1, name: "Admin"},
    {id: 2, name: "Sales"},
    {id: 3, name: "HR"},
    {id: 4, name: "Purchase"}
  ];

  onButtonClick(department){
      this.router.navigate(['/department', department.id])
  }



}
