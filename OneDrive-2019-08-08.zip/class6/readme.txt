# Reactive Forms or Model Driven Forms

> Code and the logic resides in the component class
> NO two way binding
> Well suited for complex scenarios
> Dynamic form fields
> Dynamic form validation
> Easy for Unit testing


# Routing

Routing is an essential part for any application
as routing allows us to navigate from one page to another by changing the URL

# Two way
> Add routing module at the time of creating a new project using angular/cli
> Manually create a routing module

# Routing Module
# Routes and Naivation
# router-outlet
# routerLink
# routerLinkActive
# redirect
# Wild card router
# Route Parameters


http://localhost:4200/employee
http://localhost:4200/department






