package com.social.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.Blocked;

public interface BlockedRepository extends CrudRepository<Blocked, Long>{

}
