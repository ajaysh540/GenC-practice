package com.social.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.Follow;

public interface FollowRepository extends CrudRepository<Follow, Long>{
	

}
