import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  login : Boolean;
  constructor(){
  this.login=true;
  }
  showLogin(){
    if(!this.login)
    this.login=!this.login;
    console.log(this.login);
  }
  showRegister(){
    if(this.login)
    this.login=!this.login;
    console.log(this.login);
  }
  checkLogin(){
    return this.login;
  }
}

