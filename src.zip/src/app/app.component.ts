import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  login : Boolean;
  constructor(){
  this.login=true;
  }
  showLogin(){
    this.login=!this.login;
    console.log(this.login);
  }
  showRegister(){
    this.login=!this.login;
    console.log(this.login);
  }
  checkLogin(){
    return this.login;
  }
}

