import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { LeftbarComponent } from './leftbar/leftbar.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { UploadComponent } from './upload/upload.component';
import { SingleUploadComponent } from './single-upload/single-upload.component';
import { MultiUploadComponent } from './multi-upload/multi-upload.component';
import { MymediaComponent } from './mymedia/mymedia.component';
import { FollowersComponent } from './followers/followers.component';
import { AccountComponent } from './account/account.component';

import { NewsfeedComponent } from './newsfeed/newsfeed.component';
import { BlockedComponent } from './blocked/blocked.component';
import { UpdateComponent } from './update/update.component';
import { SearchaComponent } from './searcha/searcha.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    LeftbarComponent,
    RegisterComponent,
    HomeComponent,
    UploadComponent,
    SingleUploadComponent,
    MultiUploadComponent,
    MymediaComponent,
    FollowersComponent,
    AccountComponent,
    NewsfeedComponent,
    BlockedComponent,
    UpdateComponent,
    SearchaComponent
  ],
  imports: [
    BrowserModule,
    
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
