import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.scss']
})
export class LeftPanelComponent extends AppComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
  }
  showLogin(){
    super.showLogin();
  }
  showRegister(){
    super.showRegister();
  }
}
