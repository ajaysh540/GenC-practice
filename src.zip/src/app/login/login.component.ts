import { Component, OnInit } from '@angular/core';
import { User } from 'src/model/user';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/services/user-auth.service';
import { error } from 'util';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: String;
  password: String;
  invalidLogin: boolean = false;
  users: User;
  loading: boolean;
  constructor(private router: Router, private loginService: UserAuthService) { }

  ngOnInit() {

  }

   login():any {
    console.log(this.users);

    if(this.users!=null){
      this.router.navigate(['home']);
    this.invalidLogin = false;
    console.log(this.users);
    localStorage.setItem("userId", this.users.id.toString());
    }
    else{
      this.invalidLogin = true;
    }
  }



  async onSubmit() {
    console.log("In Submit");
    this.loading = true;
    let user =await this.loginService.checkUser(this.username, this.password);
    user.subscribe((result)=>
      this.users=result,error=>alert(`${error.message}\nWaiting for response from server`));

      user.toPromise().then(
        this.login(),
      )
  }
}
