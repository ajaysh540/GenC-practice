import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-upload',
  templateUrl: './multi-upload.component.html',
  styleUrls: ['./multi-upload.component.css']
})
export class MultiUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
