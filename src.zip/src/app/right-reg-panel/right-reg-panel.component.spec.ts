import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RightRegPanelComponent } from './right-reg-panel.component';

describe('RightRegPanelComponent', () => {
  let component: RightRegPanelComponent;
  let fixture: ComponentFixture<RightRegPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RightRegPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RightRegPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
