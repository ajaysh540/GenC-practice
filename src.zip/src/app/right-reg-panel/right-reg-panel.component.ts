import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-reg-panel',
  templateUrl: './right-reg-panel.component.html',
  styleUrls: ['./right-reg-panel.component.scss']
})
export class RightRegPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
