import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-upload',
  templateUrl: './single-upload.component.html',
  styleUrls: ['./single-upload.component.css']
})
export class SingleUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
