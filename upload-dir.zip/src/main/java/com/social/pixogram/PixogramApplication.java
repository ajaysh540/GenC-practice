package com.social.pixogram;

import java.util.stream.Stream;

import javax.annotation.Resource;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.social.pixogram.model.BlockedDetails;
import com.social.pixogram.model.FollowDetails;
import com.social.pixogram.model.MediaDetails;
import com.social.pixogram.model.UserDetails;
import com.social.pixogram.repo.BlockedRepo;
import com.social.pixogram.repo.FollowRepo;
import com.social.pixogram.repo.MediaRepo;
import com.social.pixogram.repo.UserRepo;
import com.social.pixogram.service.StorageService;

@SpringBootApplication
public class PixogramApplication implements CommandLineRunner {

	@Resource
	StorageService storageService;
	@Resource
	MediaRepo mediaRepo;

	public static void main(String[] args) {
		SpringApplication.run(PixogramApplication.class, args);
	}
	
	@Bean
	ApplicationRunner init(UserRepo userRepo) {
		return args -> {
			Stream.of(new UserDetails("User1", "user1@gmail.com", "root"), new UserDetails("User2", "user2@gmail.com", "root"),
					new UserDetails("User3", "user3@gmail.com", "root"), new UserDetails("User4", "user4@gmail.com", "root"),
					new UserDetails("User5", "user5@gmail.com", "root"), new UserDetails("User6", "user6@gmail.com", "root"),
					new UserDetails("User7", "user7@gmail.com", "root"), new UserDetails("User8", "user8@gmail.com", "root"),
					new UserDetails("User9", "user9@gmail.com", "root"), new UserDetails("User10", "user10@gmail.com", "root"))
					.forEach(user -> {
						userRepo.save(user);
					});
			userRepo.findAll().forEach(System.out::println);
		};
	}

	@Bean
	ApplicationRunner init1(MediaRepo mediaRepo, StorageService storageService) {
		return args -> {
			Stream.of(new MediaDetails(1, "dummy1.jpg", -1, 45, 8), new MediaDetails(1, "dummy2.jpg", -1, 56, 7),
					new MediaDetails(2, "dummy3.jpg", -1, 45, 19), new MediaDetails(2, "dummy4.jpg", -1, 12, 0),
					new MediaDetails(3, "dummy5.jpg", -1, 45, 88), new MediaDetails(3, "dummy6.jpg", -1, 77, 23),
					new MediaDetails(4, "dummy7.jpg", -1, 76, 56), new MediaDetails(4, "dummy8.jpg", -1, 12, 23),
					new MediaDetails(5, "dummy9.jpg", -1, 23, 56), new MediaDetails(5, "dummy10.jpg", -1, 67, 56),
					new MediaDetails(6, "dummy11.jpg", -1, 88, 99), new MediaDetails(6, "dummy12.jpg", -1, 12, 23),
					new MediaDetails(7, "dummy13.jpg", -1, 99, 100), new MediaDetails(7, "dummy14.jpg", -1, 11, 22),
					new MediaDetails(8, "dummy15.jpg", -1, 88, 44), new MediaDetails(8, "dummy16.jpg", -1, 67, 9),
					new MediaDetails(9, "dummy17.jpg", -1, 0, 0), new MediaDetails(9, "dummy18.jpg", -1, 98, 0)).forEach(media -> {
						mediaRepo.save(media);
					});
			mediaRepo.findAll().forEach(System.out::println);
		};
	}

	@Bean
	ApplicationRunner init2(FollowRepo followRepo) {
		return args -> {
			Stream.of(new FollowDetails(1, 2), new FollowDetails(1, 3), new FollowDetails(1, 4), new FollowDetails(1, 10), new FollowDetails(1, 3),
					new FollowDetails(2, 1), new FollowDetails(2, 5), new FollowDetails(2, 9), new FollowDetails(4, 5), new FollowDetails(3, 8),
					new FollowDetails(4, 1), new FollowDetails(6, 7), new FollowDetails(6, 3), new FollowDetails(5, 3), new FollowDetails(7, 6),
					new FollowDetails(7, 1), new FollowDetails(7, 2), new FollowDetails(9, 10), new FollowDetails(9, 4), new FollowDetails(6, 8))
					.forEach(follow -> {
						followRepo.save(follow);
					});
			followRepo.findAll().forEach(System.out::println);
		};
	}

	@Bean
	ApplicationRunner init3(BlockedRepo blockedRepo) {
		return args -> {
			Stream.of(new BlockedDetails(1, 6), new BlockedDetails(1, 3), new BlockedDetails(2, 9), new BlockedDetails(2, 7), new BlockedDetails(10, 1),
					new BlockedDetails(10, 3), new BlockedDetails(9, 1), new BlockedDetails(8, 10)).forEach(blocked -> {
						blockedRepo.save(blocked);
					});
			blockedRepo.findAll().forEach(System.out::println);
		};
	}

	@Override
	public void run(String... arg) throws Exception {
		//storageService.deleteAll();
		storageService.init();
	}

}
