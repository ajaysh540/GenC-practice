package com.social.pixogram.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="likes")
@SequenceGenerator(name = "seq5", initialValue = 1, allocationSize = 100)
public class LikesDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq5")
	Integer likeId;
	
	@Override
	public String toString() {
		return "LikesDetails [likeId=" + likeId + ", userId=" + userId + ", mediaId=" + mediaId + "]";
	}
	public Integer getLikeId() {
		return likeId;
	}
	public void setLikeId(Integer likeId) {
		this.likeId = likeId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getMediaId() {
		return mediaId;
	}
	public void setMediaId(Integer mediaId) {
		this.mediaId = mediaId;
	}
	Integer userId;
	Integer mediaId;
}
