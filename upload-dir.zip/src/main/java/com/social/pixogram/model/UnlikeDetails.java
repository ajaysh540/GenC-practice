package com.social.pixogram.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="unlike")
@SequenceGenerator(name = "seq2", initialValue = 1, allocationSize = 100)
public class UnlikeDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq2")
	Integer unlikeId;
	
	Integer userId;
	
	Integer postId;
	
}
