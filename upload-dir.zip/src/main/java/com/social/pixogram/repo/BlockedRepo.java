package com.social.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.BlockedDetails;

public interface BlockedRepo extends CrudRepository<BlockedDetails, Long>{

}
