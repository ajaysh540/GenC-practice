package com.social.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.FollowDetails;

public interface FollowRepo extends CrudRepository<FollowDetails, Long>{

}
