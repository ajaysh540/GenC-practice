package com.social.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.MediaDetails;

public interface MediaRepo extends CrudRepository<MediaDetails, Long> {

}
