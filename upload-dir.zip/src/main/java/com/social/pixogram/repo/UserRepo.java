package com.social.pixogram.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.UserDetails;

public interface UserRepo extends CrudRepository<UserDetails, Long>{

	@Query(value ="Select u from UserDetails u where u.name like ?1 and u.password like ?2")
	List<UserDetails> findByUserAndPassword( String username, String password);

	
	
}
