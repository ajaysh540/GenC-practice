package com.social.pixogram.service;

import java.util.List;


import com.social.pixogram.model.BlockedDetails;


public interface BlockedService {
	
	public List<BlockedDetails> getAllBlocked(); 
	
	public void unblockUser(Long id);
	
	public BlockedDetails blockUser(BlockedDetails block);
	
}
