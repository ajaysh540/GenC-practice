package com.social.pixogram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.pixogram.model.BlockedDetails;
import com.social.pixogram.repo.BlockedRepo;

@Service
public class BlockedServiceImpl implements BlockedService{

	@Autowired
	BlockedRepo blockedRepo;

	@Override
	public List<BlockedDetails> getAllBlocked() {
		return (List<BlockedDetails>) blockedRepo.findAll();
	}

	@Override
	public void unblockUser(Long id) {
		blockedRepo.deleteById(id);
		return;
	}

	@Override
	public BlockedDetails blockUser(BlockedDetails blocked) {
		return blockedRepo.save(blocked);
	}
	
	
}
