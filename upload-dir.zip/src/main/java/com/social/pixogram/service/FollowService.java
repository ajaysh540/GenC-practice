package com.social.pixogram.service;

import java.util.List;

import com.social.pixogram.model.FollowDetails;

public interface FollowService {

	public FollowDetails follow(FollowDetails follow);

	public List<FollowDetails> getAll();

	public void unfollow(long id);
}
