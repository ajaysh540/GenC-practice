package com.social.pixogram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.pixogram.model.FollowDetails;
import com.social.pixogram.repo.FollowRepo;

@Service
public class FollowServiceImpl implements FollowService {

	@Autowired
	FollowRepo followRepo;

	@Override
	public FollowDetails follow(FollowDetails follow) {
		return followRepo.save(follow);
	}

	@Override
	public List<FollowDetails> getAll() {
		return (List<FollowDetails>) followRepo.findAll();
	}


	@Override
	public void unfollow(long id) {
		followRepo.deleteById(id);
		return;
	}

}
