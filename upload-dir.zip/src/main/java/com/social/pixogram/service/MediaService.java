package com.social.pixogram.service;

import java.util.List;

import com.social.pixogram.model.MediaDetails;

public interface MediaService {

	public List<MediaDetails> getUsersMedia(int userId);

	public MediaDetails postMedia(MediaDetails m);
}
