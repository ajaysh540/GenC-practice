package com.social.pixogram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.pixogram.model.MediaDetails;
import com.social.pixogram.repo.MediaRepo;

@Service
public class MediaServiceImpl implements MediaService {

	@Autowired
	MediaRepo mediaRepo;

	@Override
	public List<MediaDetails> getUsersMedia(int userId) {
		return (List<MediaDetails>) mediaRepo.findAll();
	}

	@Override
	public MediaDetails postMedia(MediaDetails m) {
		// TODO Auto-generated method stub
		return mediaRepo.save(new MediaDetails(m.getUserId(), m.getUrl(), m.getTitle(), m.getDescription(), m.getTags()));
	}

}
