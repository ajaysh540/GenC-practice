package com.social.pixogram.service;

import java.util.List;
import java.util.Optional;

import com.social.pixogram.model.UserDetails;


public interface UserService {

	public List<UserDetails> getUsers();
	
	public UserDetails createUser(UserDetails user);
	
	public Optional<UserDetails> getUserById(Long userId);

	public List<UserDetails> findByUserAndPassword(String username, String password);
	
	
}
