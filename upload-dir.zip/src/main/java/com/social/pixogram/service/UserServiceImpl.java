package com.social.pixogram.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.pixogram.model.UserDetails;
import com.social.pixogram.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepo userRepo;
	
	@Override
	public List<UserDetails> getUsers() {
		return (List<UserDetails>) userRepo.findAll();
	}

	@Override
	public UserDetails createUser(UserDetails user) {
		return userRepo.save(new UserDetails(user.getName(), user.getEmail(), user.getPassword()));
	}

	@Override
	public Optional<UserDetails> getUserById(Long userId) {
		return (Optional<UserDetails>) userRepo.findById(userId);
	}

	@Override
	public List<UserDetails> findByUserAndPassword(String username, String password) {
		// TODO Auto-generated method stub
	return userRepo.findByUserAndPassword(username, password);
	}




}
